library(testthat)
library(xberlin)

test_check("xberlin")
